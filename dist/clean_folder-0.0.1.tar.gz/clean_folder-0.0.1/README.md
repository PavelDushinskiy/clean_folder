# Package for sorting files in directory
<ul>
<li>All files and folders are renamed using the normalize function;</li>
<li>File extensions do not change after renaming;</li>
<li>Empty folders are deleted;</li>
<li>The unpacked contents of the archive are transferred to the archives folder
    in a subfolder named the same as the archive;</li>
<li>Files whose extensions are unknown remain unchanged.</li>
</ul>
author: <b><u>Pavlo Dushinsky</b></u>